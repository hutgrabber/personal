#include <stdio.h>

int main()
{
  char ch = 'a';
  printf("Address is %p\n", &ch);
  getchar();
  return 0;
}
