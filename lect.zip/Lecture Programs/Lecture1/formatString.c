#include <stdio.h>
#include <string.h>

void main(int argc, char** argv)
{
    char* userPassword = "This is a user password.\n";
    char* adminPassword = "This is an admin password.\n";

    printf(argv[1]);
}
