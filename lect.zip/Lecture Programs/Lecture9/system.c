#include<stdlib.h>

void main()
{
system("/bin/sh");
}
